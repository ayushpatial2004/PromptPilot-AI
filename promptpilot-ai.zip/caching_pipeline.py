#!/usr/bin/env python3
"""
PromptPilot AI - Modern Prompt Caching Pipeline
Principal AI Platform Engineer Reference Implementation

This module contains a fully optimized, production-ready implementation of
the three-layer, cache-friendly prompt architecture using the modern Google GenAI SDK.

Hierarchy Design:
  - LAYER 1 (Top): Static Global System Instructions (Never changes, cached)
  - LAYER 2 (Middle): Heavy Reference Data / Context (Changes rarely, cached)
  - LAYER 3 (Bottom): Dynamic User Queries (Changes every request, uncached)

All heavy reference elements are wrapped in strict, semantic XML tags
and referenced explicitly in the execution instructions to prevent attention loss.
"""

import os
import sys
import json
from typing import Dict, Any, List, Optional

# Enforce clean importing of the modern Google GenAI SDK
try:
    from google import genai
    from google.genai import types
    from google.genai.errors import APIError
except ImportError:
    # Fallback/Helpful reminder for environment dependencies
    print("[WARNING] The 'google-genai' SDK is not installed. To run this script, run: pip install google-genai", file=sys.stderr)
    genai = None


# =====================================================================
# LAYER 1: Static Global System Instructions
# =====================================================================
SYSTEM_INSTRUCTIONS = (
    "You are PromptPilot AI, a world-class prompt engineer and quality evaluator.\n"
    "Your task is to transform a weak, vague, or incomplete input prompt into a highly "
    "structured, expert-level prompt.\n"
    "You must analyze the context, detect requirements, resolve ambiguities, and output "
    "a detailed optimization analysis in valid JSON format."
)


# =====================================================================
# LAYER 2: Heavy Reference Data / Context (Changes rarely)
# =====================================================================
DOMAIN_CONTEXT_DATA = {
    "general": (
        "Focus on clarity, actionable structures, explicit constraints, and clear "
        "definitions of target audiences or outputs. Avoid buzzwords and prioritize precision."
    ),
    "creative": (
        "Focus on rich sensory details, emotional resonance, narrative structure, "
        "pacing guidelines, and stylistic tone attributes. Encourage expressive yet structured prose."
    ),
    "technical": (
        "Focus on strict syntax, functional requirements, architectural boundaries, edge-case "
        "handling, error mitigation, and structural formatting. Request modularity."
    )
}

def build_reference_context(domain: str, user_profile: Optional[Dict[str, str]] = None, custom_template: Optional[Dict[str, str]] = None) -> str:
    """
    Builds the Layer 2 Reference Context, wrapping all heavy reference data
    in semantic XML tags to leverage structural attention and cache boundaries.
    """
    domain_ctx = DOMAIN_CONTEXT_DATA.get(domain, DOMAIN_CONTEXT_DATA["general"])
    
    parts = []
    parts.append("<reference_context>")
    parts.append(f"  <domain_instruction>{domain_ctx}</domain_instruction>")
    
    # Inject user profile details if present
    if user_profile:
        parts.append("  <user_profile>")
        if user_profile.get("role"):
            parts.append(f"    <role>{user_profile['role'].strip()}</role>")
        if user_profile.get("stack"):
            parts.append(f"    <stack>{user_profile['stack'].strip()}</stack>")
        if user_profile.get("rules"):
            parts.append(f"    <rules>{user_profile['rules'].strip()}</rules>")
        parts.append("  </user_profile>")
        
    # Inject custom template rules if present
    if custom_template:
        parts.append("  <custom_template>")
        if custom_template.get("name"):
            parts.append(f"    <name>{custom_template['name'].strip()}</name>")
        if custom_template.get("content"):
            parts.append(f"    <content>{custom_template['content'].strip()}</content>")
        parts.append("  </custom_template>")
        
    parts.append("</reference_context>")
    return "\n".join(parts)


# =====================================================================
# LAYER 3: Dynamic User Queries / Execution Block (Changes every request)
# =====================================================================
def build_execution_prompt(prompt_text: str, mode: str = "technical") -> str:
    """
    Builds the Layer 3 Execution Block. Crucially, this references the
    semantic XML tags defined in Layer 2 to ensure absolute attention lock.
    """
    return (
        f"<input_prompt>{prompt_text}</input_prompt>\n\n"
        "EXECUTION STEP:\n"
        "Using the rules and specifications defined in <reference_context>, analyze and transform "
        "the prompt provided in <input_prompt> into a highly detailed, professional, structured version.\n\n"
        f"Enhancement Mode: {mode}\n\n"
        "Return your response in the following strict JSON format, with absolutely no surrounding conversation, "
        "preamble, or markdown formatting blocks (other than valid JSON):\n\n"
        "{\n"
        '  "enhanced_prompt": "<The fully transformed, complete, expert-level prompt text>",\n'
        '  "clarity_score": <Integer from 0 to 100 assessing the original prompt\'s clarity>,\n'
        '  "specificity_score": <Integer from 0 to 100 assessing the original prompt\'s specificity>,\n'
        '  "quality_score": <Integer from 0 to 100 assessing the original prompt\'s overall quality>,\n'
        '  "domain_detected": "<The main category or domain detected, e.g. frontend, backend, UI/UX, etc.>",\n'
        '  "missing_requirements": ["Requirement 1 missing", "Requirement 2 missing", ...],\n'
        '  "transformation_insight": "<Brief explanation of the specific improvements applied during transformation>",\n'
        '  "ambiguities_resolved": ["Resolved ambiguity 1", "Resolved ambiguity 2", ...]\n'
        "}"
    )


# =====================================================================
# Production API Execution with Modern SDK
# =====================================================================
def optimize_and_execute(
    prompt: str,
    domain: str = "general",
    mode: str = "technical",
    user_profile: Optional[Dict[str, str]] = None,
    custom_template: Optional[Dict[str, str]] = None,
    api_key: Optional[str] = None
) -> Dict[str, Any]:
    """
    Assembles the three-layer layout and invokes the modern Google GenAI API.
    
    By segregating the static instructions (Layer 1) and the heavy static-to-semi-static
    context (Layer 2) from the highly dynamic query (Layer 3), Gemini's underlying 
    Prompt Caching engine can perfectly cache Layers 1 and 2, yielding massive speedups 
    and substantial cost reductions.
    """
    if not genai:
        print("[ERROR] Please install the google-genai library first: pip install google-genai")
        return {"error": "google-genai library missing"}
        
    # Lazy initialize client
    client = genai.Client(api_key=api_key or os.environ.get("GEMINI_API_KEY"))
    
    # Assemble Layout Layers
    # Layer 1
    system_instruction = SYSTEM_INSTRUCTIONS
    
    # Layer 2
    reference_context = build_reference_context(
        domain=domain,
        user_profile=user_profile,
        custom_template=custom_template
    )
    
    # Layer 3
    execution_block = build_execution_prompt(
        prompt_text=prompt,
        mode=mode
    )
    
    # Final Payload Composition
    # Combining Layer 2 and Layer 3 in the user contents, keeping Layer 1 strictly as system_instruction
    combined_contents = f"{reference_context}\n\n{execution_block}"
    
    print("--- [PROMPT PILOT CACHING PIPELINE LAYOUT] ---")
    print(f"[LAYER 1 - SYSTEM INSTRUCTION (Cached)]\n{system_instruction}\n")
    print(f"[LAYER 2 - REFERENCE CONTEXT (Cached when stable)]\n{reference_context}\n")
    print(f"[LAYER 3 - EXECUTION BLOCK (Dynamic / Not cached)]\n{execution_block}\n")
    print("-----------------------------------------------")
    
    try:
        # We leverage the powerful gemini-2.5-flash model
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=combined_contents,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=0.2,
                max_output_tokens=1500,
                # Enforce JSON output mode to match our dynamic execution contract
                response_mime_type="application/json"
            )
        )
        
        # Parse output safely
        result_text = response.text.strip()
        return json.loads(result_text)
        
    except APIError as e:
        print(f"[API ERROR] Failed to generate content from Gemini API: {e}", file=sys.stderr)
        return {"error": f"API Error: {str(e)}"}
    except json.JSONDecodeError as e:
        print(f"[PARSE ERROR] Failed to parse JSON response from Gemini API: {e}", file=sys.stderr)
        # Fallback raw output
        return {"error": "JSON parse error", "raw_response": response.text if 'response' in locals() else ""}
    except Exception as e:
        print(f"[UNEXPECTED ERROR] {e}", file=sys.stderr)
        return {"error": str(e)}


if __name__ == "__main__":
    # Quick sanity check or demonstration run
    test_prompt = "Write a React component for a clean to-do list with checkboxes."
    test_profile = {
        "role": "Senior Frontend Architect",
        "stack": "React 19, TypeScript, Tailwind CSS, Vite",
        "rules": "Never write mock endpoints; use modern ES6 syntax; write descriptive IDs."
    }
    
    print("Initializing test run...")
    print(f"Original Prompt: '{test_prompt}'\n")
    
    # Demonstrate local assembly without API call if no key is provided
    if not os.environ.get("GEMINI_API_KEY"):
        print("[NOTICE] GEMINI_API_KEY not found in environment. Displaying prompt composition layers only.")
        sys_inst = SYSTEM_INSTRUCTIONS
        ref_ctx = build_reference_context("technical", test_profile)
        exec_blk = build_execution_prompt(test_prompt, "technical")
        
        print("\n=== LAYER 1: SYSTEM INSTRUCTIONS ===")
        print(sys_inst)
        print("\n=== LAYER 2: REFERENCE CONTEXT ===")
        print(ref_ctx)
        print("\n=== LAYER 3: EXECUTION QUERY ===")
        print(exec_blk)
        print("\n=================================")
    else:
        print("[ACTIVE] GEMINI_API_KEY detected. Executing API call...")
        output = optimize_and_execute(
            prompt=test_prompt,
            domain="technical",
            mode="technical",
            user_profile=test_profile
        )
        print("\n=== OPTIMIZATION RESULT ===")
        print(json.dumps(output, indent=2))
