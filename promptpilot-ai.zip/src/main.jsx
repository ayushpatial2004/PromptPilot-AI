import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

// ─── Chrome Extension API Mock for Standalone App Preview ─────────────────────
if (typeof window.chrome === 'undefined' || !window.chrome.runtime) {
  const localStorageMock = {
    get: (keys, callback) => {
      const result = {};
      if (typeof keys === 'string') {
        const val = window.localStorage.getItem(`pp_${keys}`);
        try {
          result[keys] = val ? JSON.parse(val) : undefined;
        } catch (_) {
          result[keys] = val || undefined;
        }
      } else if (Array.isArray(keys)) {
        keys.forEach(key => {
          const val = window.localStorage.getItem(`pp_${key}`);
          try {
            result[key] = val ? JSON.parse(val) : undefined;
          } catch (_) {
            result[key] = val || undefined;
          }
        });
      } else if (typeof keys === 'object' && keys !== null) {
        Object.entries(keys).forEach(([key, defaultVal]) => {
          const val = window.localStorage.getItem(`pp_${key}`);
          if (val === null) {
            result[key] = defaultVal;
          } else {
            try {
              result[key] = JSON.parse(val);
            } catch (_) {
              result[key] = val;
            }
          }
        });
      }
      if (callback) callback(result);
      return Promise.resolve(result);
    },
    set: (items, callback) => {
      Object.entries(items).forEach(([key, value]) => {
        window.localStorage.setItem(`pp_${key}`, typeof value === 'object' ? JSON.stringify(value) : value);
      });
      if (callback) callback();
      return Promise.resolve();
    },
    remove: (keys, callback) => {
      const keysArray = Array.isArray(keys) ? keys : [keys];
      keysArray.forEach(key => window.localStorage.removeItem(`pp_${key}`));
      if (callback) callback();
      return Promise.resolve();
    },
    clear: (callback) => {
      window.localStorage.clear();
      if (callback) callback();
      return Promise.resolve();
    }
  };

  window.chrome = {
    runtime: {
      onInstalled: { addListener: () => {} },
      onMessage: { addListener: () => {} },
      sendMessage: async (msg, callback) => {
        console.log('Mocked chrome.runtime.sendMessage received:', msg);
        if (msg.type === 'PP_API') {
          try {
            const { callAPI } = await import('./background.js');
            const response = await callAPI(msg);
            const result = { ok: true, data: response };
            if (callback) callback(result);
            return result;
          } catch (err) {
            const result = { ok: false, error: err.message };
            if (callback) callback(result);
            return result;
          }
        }
        return { ok: false, error: 'Unknown message type in mock' };
      }
    },
    storage: {
      local: localStorageMock
    },
    contextMenus: {
      create: () => {},
      onClicked: { addListener: () => {} }
    },
    commands: {
      onCommand: { addListener: () => {} }
    },
    tabs: {
      sendMessage: () => {},
      query: () => Promise.resolve([])
    },
    scripting: {
      executeScript: () => Promise.resolve([])
    }
  };
}

import App from './App.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
